plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
}

android {
    namespace = "com.example.myapplication"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.myapplication"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        compose = true
        viewBinding = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Navegación en Jetpack Compose
    implementation("androidx.navigation:navigation-compose:2.7.2")

    // Dependencias principales de Jetpack Compose
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // ViewBinding
    implementation("androidx.databinding:viewbinding:7.0.0")

    // Herramientas para la depuración en Compose
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)

    // Pruebas unitarias
    testImplementation(libs.junit)

    // Pruebas instrumentadas
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)

    // Extensiones adicionales para Jetpack Compose
    implementation("androidx.compose.runtime:runtime:1.5.3") // Para manejar estados y recomposiciones
    implementation("androidx.compose.foundation:foundation:1.5.3") // Widgets básicos (Column, Row, Box, etc.)
    implementation("androidx.compose.material:material:1.5.3") // Material Design estándar
    implementation("androidx.compose.material3:material3:1.2.0") // Material Design 3

    // Animaciones en Compose
    implementation("androidx.compose.animation:animation:1.5.3")
    implementation("androidx.compose.animation:animation-graphics:1.5.3")

    // UI Test para Compose
    androidTestImplementation("androidx.compose.ui:ui-test-junit4:1.5.3")
    debugImplementation("androidx.compose.ui:ui-tooling:1.5.3")
    debugImplementation("androidx.compose.ui:ui-test-manifest:1.5.3")

    // Para trabajar con RecyclerView o LazyColumn (si usas adaptadores)
    implementation("androidx.compose.foundation:foundation-layout:1.5.3")

    // Accompanist (biblioteca para soporte adicional en Compose, opcional)
    implementation("com.google.accompanist:accompanist-systemuicontroller:0.30.1") // Control del sistema UI
    implementation("com.google.accompanist:accompanist-navigation-animation:0.30.1") // Navegación animada
    implementation("com.google.accompanist:accompanist-insets:0.30.1") // Manejo de insets como barras de estado

    // Librerías para compatibilidad y soporte adicional
    implementation("androidx.appcompat:appcompat:1.7.0-alpha03")
    implementation("com.google.android.material:material:1.9.0")
}

