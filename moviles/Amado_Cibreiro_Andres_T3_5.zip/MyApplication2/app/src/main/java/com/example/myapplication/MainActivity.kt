package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.databinding.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Navigation()
        }
    }
}

@Composable
fun Navigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "main") {
        composable("main") { MainScreen(navController) }
        composable("linear_layout") { LinearLayoutScreen(navController) }
        composable("frame_layout") { FrameLayoutScreen(navController) }
        composable("relative_layout") { RelativeLayoutScreen(navController) }
        composable("table_layout") { TableLayoutScreen(navController) }
        composable("grid_layout") { GridLayoutScreen(navController) }
    }
}

@Composable
fun MainScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = { navController.navigate("linear_layout") }) {
            Text("Ver LinearLayout")
        }
        Button(onClick = { navController.navigate("frame_layout") }) {
            Text("Ver FrameLayout")
        }
        Button(onClick = { navController.navigate("relative_layout") }) {
            Text("Ver RelativeLayout")
        }
        Button(onClick = { navController.navigate("table_layout") }) {
            Text("Ver TableLayout")
        }
        Button(onClick = { navController.navigate("grid_layout") }) {
            Text("Ver GridLayout")
        }
    }
}

@Composable
fun LinearLayoutScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AndroidView(
            factory = { context ->
                val binding = LinearLayoutBinding.inflate(LayoutInflater.from(context))
                binding.root
            },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = { navController.popBackStack() }) {
            Text("Volver a la Principal")
        }
    }
}

@Composable
fun FrameLayoutScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AndroidView(
            factory = { context ->
                val binding = FrameLayoutBinding.inflate(LayoutInflater.from(context))
                binding.root
            },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = { navController.popBackStack() }) {
            Text("Volver a la Principal")
        }
    }
}

@Composable
fun RelativeLayoutScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AndroidView(
            factory = { context ->
                val binding = RelativeLayoutBinding.inflate(LayoutInflater.from(context))
                binding.root
            },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = { navController.popBackStack() }) {
            Text("Volver a la Principal")
        }
    }
}

@Composable
fun TableLayoutScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AndroidView(
            factory = { context ->
                val binding = TableLayoutBinding.inflate(LayoutInflater.from(context))
                binding.root
            },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = { navController.popBackStack() }) {
            Text("Volver a la Principal")
        }
    }
}


@Composable
fun GridLayoutScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AndroidView(
            factory = { context ->
                val binding = GridLayoutBinding.inflate(LayoutInflater.from(context))
                binding.root
            },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = { navController.popBackStack() }) {
            Text("Volver a la Principal")
        }
    }
}
