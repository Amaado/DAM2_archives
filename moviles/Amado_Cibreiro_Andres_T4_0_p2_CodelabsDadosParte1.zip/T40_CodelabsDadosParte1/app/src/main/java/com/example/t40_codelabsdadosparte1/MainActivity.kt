package com.example.t40_codelabsdadosparte1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.t40_codelabsdadosparte1.ui.theme.T40_CodelabsDadosParte1Theme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            T40_CodelabsDadosParte1Theme {
                DiceRollerApp()
            }
        }
    }
}

@Composable
fun DiceRollerApp() {
    var dice1Result by remember { mutableStateOf(1) }
    var dice2Result by remember { mutableStateOf(1) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        content = { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DiceImage(dice1Result)
                    DiceImage(dice2Result)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = {
                    dice1Result = Random.nextInt(1, 7)
                    dice2Result = Random.nextInt(1, 7)
                }) {
                    Text("Lanzar Dados")
                }
            }
        }
    )
}

@Composable
fun DiceImage(diceValue: Int) {
    val diceImage = when (diceValue) {
        1 -> R.drawable.dice_1
        2 -> R.drawable.dice_2
        3 -> R.drawable.dice_3
        4 -> R.drawable.dice_4
        5 -> R.drawable.dice_5
        else -> R.drawable.dice_6
    }

    Image(
        painter = painterResource(id = diceImage),
        contentDescription = "Dice with value $diceValue",
        modifier = Modifier.size(100.dp)
    )
}

@Preview(showBackground = true)
@Composable
fun DiceRollerAppPreview() {
    T40_CodelabsDadosParte1Theme {
        DiceRollerApp()
    }
}
