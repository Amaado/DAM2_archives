package com.example.kotlinejerciciosavanzados

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.kotlinejerciciosavanzados.ui.theme.KotlinEjerciciosAvanzadosTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KotlinEjerciciosAvanzadosTheme {
                SingleExerciseScreen()
            }
        }
    }
}

@Composable
fun SingleExerciseScreen() {
    //val result = ejecutarEjercicio1(20)
    //val result = ejecutarEjercicio2(5)
    //val result = ejecutarEjercicio3(12345)
    //val result = ejecutarEjercicio4(1, 50)
    //val result = ejecutarEjercicio5()
    //val result = ejecutarEjercicio7(5)
    //val result = ejecutarEjercicio8("programacion")
    //val result = ejecutarEjercicio9()
    //val result = ejecutarEjercicio10(listOf(3, 5, 7, 2, 8, -1, 4))
    val result = ejecutarEjercicio11(4)

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Resultado del ejercicio seleccionado:\n\n$result",
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// Funciones de los ejercicios

fun ejecutarEjercicio1(limite: Int): String {
    var a = 0
    var b = 1
    val resultado = StringBuilder("Serie de Fibonacci hasta $limite:\n")
    while (a <= limite) {
        resultado.append("$a ")
        val temp = a
        a = b
        b += temp
    }
    return resultado.toString()
}

fun ejecutarEjercicio2(numero: Int): String {
    var factorial = 1
    for (i in 1..numero) {
        factorial *= i
    }
    return "El factorial de $numero es: $factorial"
}

fun ejecutarEjercicio3(numero: Int): String {
    var num = numero
    var suma = 0
    do {
        suma += num % 10
        num /= 10
    } while (num != 0)
    return "La suma de los dígitos de $numero es: $suma"
}

fun ejecutarEjercicio4(inicio: Int, fin: Int): String {
    val resultado = StringBuilder("Números primos entre $inicio y $fin:\n")
    for (num in inicio..fin) {
        var esPrimo = true
        if (num < 2) esPrimo = false
        for (i in 2 until num) {
            if (num % i == 0) {
                esPrimo = false
                break
            }
        }
        if (esPrimo) resultado.append("$num ")
    }
    return resultado.toString()
}

fun ejecutarEjercicio5(): String {
    val resultado = StringBuilder("Tablas de multiplicar del 1 al 10:\n")
    for (i in 1..10) {
        for (j in 1..10) {
            resultado.append(String.format("%4d", i * j))
        }
        resultado.append("\n")
    }
    return resultado.toString()
}

fun ejecutarEjercicio7(altura: Int): String {
    val resultado = StringBuilder("Triángulo de asteriscos:\n")
    for (i in 1..altura) {
        val espacios = " ".repeat(altura - i)
        val asteriscos = "*".repeat(2 * i - 1)
        resultado.append(espacios + asteriscos + "\n")
    }
    return resultado.toString()
}

fun ejecutarEjercicio8(cadena: String): String {
    val frecuencia = mutableMapOf<Char, Int>()
    for (caracter in cadena) {
        frecuencia[caracter] = frecuencia.getOrDefault(caracter, 0) + 1
    }
    val resultado = StringBuilder("Frecuencia de caracteres:\n")
    for ((caracter, count) in frecuencia) {
        resultado.append("$caracter: $count\n")
    }
    return resultado.toString()
}

fun ejecutarEjercicio9(): String {
    val resultado = StringBuilder("Potencias de 2 desde 2^0 hasta 2^10:\n")
    for (i in 0..10) {
        resultado.append("2^$i = ${1.shl(i)}\n")
    }
    return resultado.toString()
}

fun ejecutarEjercicio10(lista: List<Int>): String {
    var max = lista[0]
    var min = lista[0]
    for (numero in lista) {
        if (numero > max) max = numero
        if (numero < min) min = numero
    }
    return "El valor máximo es: $max\nEl valor mínimo es: $min"
}

fun ejecutarEjercicio11(tamano: Int): String {
    val resultado = StringBuilder("Cuadrado de asteriscos:\n")
    for (i in 1..tamano) {
        for (j in 1..tamano) {
            resultado.append("* ")
        }
        resultado.append("\n")
    }
    return resultado.toString()
}

@Preview(showBackground = true)
@Composable
fun AppPreview() {
    KotlinEjerciciosAvanzadosTheme {
        SingleExerciseScreen()
    }
}
