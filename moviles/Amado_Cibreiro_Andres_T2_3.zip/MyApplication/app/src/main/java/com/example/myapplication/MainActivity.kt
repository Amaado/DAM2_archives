package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.paddingFrom
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.theme.MyApplicationTheme
import java.security.AccessController
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.widget.Toast
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.util.Log
import androidx.compose.material3.*
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.*


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "mainScreen") {
                        composable("mainScreen") { mainScreen(navController) }
                        composable("loginScreen") { loginScreen(navController) }
                        composable("registerScreen") { registerScreen(navController) }
                        composable("firstScreen") { firstScreen(navController) }
                        composable("secondScreen") { secondScreen(navController) }
                        composable("systemInfoScreen") { systemInfoScreen(navController) } // Pantalla 6
                        composable("sensorInfoScreen") { sensorInfoScreen(navController) } // Pantalla 7
                        composable("intentScreen") { intentScreen(navController) } // Pantalla 8
                    }


            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Welcome $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme {
        Greeting("Amado")
    }
}

@Composable
fun mainScreen(navController: NavController) {
    // Estado para el Snackbar
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        // Host para mostrar el Snackbar
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(10.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Pantalla Main",
                color = Color.Blue,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Botones de navegación
            Button(onClick = { navController.navigate("loginScreen") }) {
                Text(text = "Ir a la Login")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { navController.navigate("registerScreen") }) {
                Text(text = "Ir a la Register")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { navController.navigate("firstScreen") }) {
                Text(text = "Ir a la pantalla primaria")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { navController.navigate("secondScreen") }) {
                Text(text = "Ir a la pantalla secundaria")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { navController.navigate("systemInfoScreen") }) {
                Text(text = "Ir a Información del Sistema")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { navController.navigate("sensorInfoScreen") }) {
                Text(text = "Ir a Información de Sensores")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { navController.navigate("intentScreen") }) {
                Text(text = "Ir a Intents")
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Botón para mostrar el Snackbar
            Button(onClick = {
                coroutineScope.launch {
                    val result = snackbarHostState.showSnackbar(
                        message = "Este es un Snackbar",
                        actionLabel = "Deshacer",
                        duration = SnackbarDuration.Short
                    )
                    when (result) {
                        SnackbarResult.ActionPerformed -> {
                            // Acción cuando se pulsa "Deshacer"
                            // Puedes agregar lógica aquí si lo deseas
                        }
                        SnackbarResult.Dismissed -> {
                            // Acción cuando se descarta el Snackbar
                            // Puedes agregar lógica aquí si lo deseas
                        }
                    }
                }
            }) {
                Text(text = "Mostrar Snackbar")
            }
        }
    }
}


@Composable
fun loginScreen(navController: NavController){
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(
            text = "Pantalla Login",
            color = Color.Blue
        )

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("mainScreen") }) {
            Text(
                text = "Ir a la Main"
            )
        }
    }

}


@Composable
fun registerScreen(navController: NavController){
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(
            text = "Pantalla Registro",
            color = Color.Blue
        )

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("mainScreen") }) {
            Text(
                text = "Ir a la Main"
            )
        }
    }

}



@Composable
fun firstScreen(navController: NavController){
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(
            text = "Pantalla primaria",
            color = Color.Blue
        )

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("mainScreen") }) {
            Text(
                text = "Ir a la Main"
            )
        }
        Button(onClick = {
            Toast.makeText(context, "Este es un Toast", Toast.LENGTH_SHORT).show()
        }) {
            Text(text = "Mostrar Toast")
        }
    }
}

@Composable
fun secondScreen(navController: NavController){
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(
            text = "Pantalla secundaria",
            color = Color.Blue
        )

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("mainScreen") }) {
            Text(
                text = "Ir a la Main"
            )
        }
    }
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(text = "Título del Dialog") },
            text = { Text(text = "Este es un mensaje en el AlertDialog.") },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text(text = "Aceptar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text(text = "Cancelar")
                }
            }
        )
    }

}


    @Composable
    fun systemInfoScreen(navController: NavController) {
        val model = android.os.Build.MODEL
        val manufacturer = android.os.Build.MANUFACTURER
        val sdkVersion = android.os.Build.VERSION.SDK_INT
        val releaseVersion = android.os.Build.VERSION.RELEASE
        val brand = android.os.Build.BRAND

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(text = "Información del Sistema", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Modelo: $model")
            Text(text = "Fabricante: $manufacturer")
            Text(text = "SDK Version: $sdkVersion")
            Text(text = "Versión de Android: $releaseVersion")
            Text(text = "Marca: $brand")
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { navController.navigate("mainScreen") }) {
                Text(text = "Volver a Main")
            }
        }
    }

    @Composable
    fun sensorInfoScreen(navController: NavController) {
        val context = LocalContext.current
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensorList = sensorManager.getSensorList(Sensor.TYPE_ALL)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()), // Para hacer scroll si la lista es larga
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            Text(text = "Información de Sensores", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            sensorList.forEach { sensor ->
                Text(text = "Nombre: ${sensor.name}")
                Text(text = "Tipo: ${sensor.stringType}")
                Text(text = "Fabricante: ${sensor.vendor}")
                Text(text = "Version: ${sensor.version}")
                Spacer(modifier = Modifier.height(8.dp))
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { navController.navigate("mainScreen") }) {
                Text(text = "Volver a Main")
            }
        }
    }

    @Composable
    fun intentScreen(navController: NavController) {
        val context = LocalContext.current

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Intent 1: Navegar entre pantallas (ya se realiza con navController)

            // Intent 2: Iniciar un servicio
            var isServiceRunning by remember { mutableStateOf(false) }

            Button(
                onClick = {
                    if (!isServiceRunning) {
                        context.startService(Intent(context, MyService::class.java))
                        isServiceRunning = true
                        Log.d("Servicio", "Servicio en ejecución")
                    } else {
                        context.stopService(Intent(context, MyService::class.java))
                        isServiceRunning = false
                        Log.d("Servicio", "Servicio finaliza ejecución")
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isServiceRunning) Color.Green else Color.Red,
                    contentColor = Color.White
                )
            ) {
                Text(text = if (isServiceRunning) "Parar Servicio" else "Iniciar Servicio")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Intent 3: Enviar un mensaje o abrir una página
            Button(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
                context.startActivity(intent)
            }) {
                Text(text = "Abrir Página Web")
            }
        }
    }

class MyService : Service() {

    override fun onCreate() {
        super.onCreate()
        Log.d("MyService", "Servicio creado")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("MyService", "Servicio iniciado")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MyService", "Servicio destruido")
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}