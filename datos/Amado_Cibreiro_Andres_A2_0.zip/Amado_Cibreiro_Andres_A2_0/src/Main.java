import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {
    public static void main(String[] args) {

        LocalDateTime fechaActual = LocalDateTime.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String fechaFormateada = fechaActual.format(formato);

        System.out.println("\n      Hola Mundo\n=======================\nMi nombre es Andrés Amado Cibreiro\nTengo 19 años\nEstoy soltero\nFecha: "+fechaFormateada);


    }
}