import org.apache.commons.io.FileUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class Main {
    public static void main(String[] args) throws Exception {
            Scanner sc = new Scanner(System.in);

            String opcion = "";
            String opcion2 = "";
            String opcion3 = "";
            String etiquetaElemento = "";
            boolean salir = false;


            while(!salir){
                System.out.println("\n=====================");
                System.out.println("  EDITOR DE FICHEROS");
                System.out.println("=====================");
                System.out.println("\033[3m"+"\nSelecciona una opción escribiendo un número"+"\033[0m");

                System.out.println("\033[1m"+"X) "+"\033[0m"+"Salir");
                System.out.println("\033[1m"+"1) "+"\033[0m"+"Listar archivos de forma simplificada");
                System.out.println("\033[1m"+"2) "+"\033[0m"+"Listar archivos de forma detallada");
                System.out.println("\033[1m"+"3) "+"\033[0m"+"Crear carpeta");
                System.out.println("\033[1m"+"4) "+"\033[0m"+"Copiar archivo");
                System.out.println("\033[1m"+"5) "+"\033[0m"+"Mover archivo");
                System.out.println("\033[1m"+"6) "+"\033[0m"+"Escribir XML");
                opcion = sc.nextLine();



                if (!isInteger(opcion)){
                    System.out.println("La opción no se reconoce, intentelo otra vez");
                }else if (opcion.toLowerCase().equalsIgnoreCase("x")){
                    salir = true;
                }else if (Integer.parseInt(opcion) == 1){
                    listarArchivos();
                }else if (Integer.parseInt(opcion) == 2){
                    listarArchivosDetallado();
                }else if (Integer.parseInt(opcion) == 3){
                    crearCarpeta();
                }else if (Integer.parseInt(opcion) == 4){
                    copiarArchivo();
                }else if (Integer.parseInt(opcion) == 5){
                    moverArchivo();
                }else if (Integer.parseInt(opcion) == 6){

                    while(!salir){
                        System.out.println("\n──────────────────────────\n──────────────────────────");
                        System.out.println("\033[3m"+"\nSelecciona el XML que deseas modificar"+"\033[0m");
                        System.out.println("\033[1m"+"X) "+"\033[0m"+"Salir");
                        System.out.println("\033[1m"+"0) "+"\033[0m"+"Volver");
                        System.out.println("\033[1m"+"1) "+"\033[0m"+"Inquilinos.xml");
                        System.out.println("\033[1m"+"2) "+"\033[0m"+"Pisos.xml");
                        System.out.println("\033[1m"+"3) "+"\033[0m"+"Propietarios.xml");
                        opcion2 = sc.nextLine();

                        if (opcion2.toLowerCase().equalsIgnoreCase("x")){
                            salir = true;
                        }else if (!isInteger(opcion2)){
                            System.out.println("La opción no se reconoce, intentelo otra vez");
                        }else if (Integer.parseInt(opcion2) == 0){
                            break;
                        }else if (Integer.parseInt(opcion2) == 1){

                            while(!salir){
                                System.out.println("\n──────────────────────────");
                                System.out.println("\nINQUILINOS.xml");
                                System.out.println("\033[3m"+"Selecciona la acción a realizar"+"\033[0m");
                                System.out.println("\033[1m"+"X) "+"\033[0m"+"Salir");
                                System.out.println("\033[1m"+"0) "+"\033[0m"+"Volver");
                                System.out.println("\033[1m"+"1) "+"\033[0m"+"Contar veces que se repite una etiqueta");
                                System.out.println("\033[1m"+"2) "+"\033[0m"+"Añadir nuevo inquilino");
                                opcion3 = sc.nextLine();

                                if (opcion3.toLowerCase().equalsIgnoreCase("x")){
                                    salir = true;
                                }else if (!isInteger(opcion3)){
                                    System.out.println("\nLa opción no se reconoce, intentelo otra vez");

                                }else if (Integer.parseInt(opcion3) == 0){
                                    break;
                                }else if (Integer.parseInt(opcion3) == 1){
                                    while(!salir){
                                        String etiquetaAbuscar = "";
                                        System.out.println("Que etiqueta deseas buscar?");
                                        etiquetaAbuscar = sc.nextLine();

                                        if(isBlank(etiquetaAbuscar)){
                                            System.out.println("\nIntroduce algún valor");
                                            System.out.println("\t─────────\t─────────\n");
                                        }else if(existeEtiqueta("./inquilinos.xml", etiquetaAbuscar)){
                                            contarElementos("./inquilinos.xml", etiquetaAbuscar);
                                            break;
                                        }else{
                                            System.out.println("\nLa etiqueta "+etiquetaAbuscar+" no existe");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe una etiqueta que exista en el xml");
                                        }
                                    }

                                }else if (Integer.parseInt(opcion3) == 2){
                                    String nombre = "";
                                    String telefono = "";
                                    String correo = "";
                                    String duracionContrato = "";

                                    System.out.println("Valor para "+"\033[1m"+"nombre"+"\033[0m"+" (String):");
                                    nombre = sc.nextLine();

                                    while(!salir){
                                        System.out.println("Valor para "+"\033[1m"+"telefono"+"\033[0m"+" (int):");
                                        telefono = sc.nextLine();

                                        if (!isInteger(String.valueOf(telefono))){
                                            System.out.println("\nLa respuesta no es del tipo requerido");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe un dato acorde al tipo que se solicita");
                                        }else{
                                            break;
                                        }
                                    }

                                    //sc.nextLine();
                                    System.out.println("Valor para "+"\033[1m"+"correo"+"\033[0m"+" (String):");
                                    correo = sc.nextLine();

                                    while(!salir){
                                        System.out.println("Valor para "+"\033[1m"+"duracionContrato"+"\033[0m"+" (int):");
                                        duracionContrato = sc.nextLine();

                                        if (!isInteger(String.valueOf(duracionContrato))){
                                            System.out.println("\nLa respuesta no es del tipo requerido");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe un dato acorde al tipo que se solicita");
                                        }else{
                                            break;
                                        }
                                    }


                                    agregarInquilino("./inquilinos.xml", nombre, Integer.parseInt(telefono), correo, Integer.parseInt(duracionContrato));
                                }else{
                                    System.out.println("La opción no se reconoce, intentelo otra vez");
                                }

                            }

                        }else if (Integer.parseInt(opcion2) == 2){
                            while(!salir){
                                System.out.println("\n──────────────────────────");
                                System.out.println("\nPISOS.xml");
                                System.out.println("\033[3m"+"Selecciona la acción a realizar"+"\033[0m");
                                System.out.println("\033[1m"+"X) "+"\033[0m"+"Salir");
                                System.out.println("\033[1m"+"0) "+"\033[0m"+"Volver");
                                System.out.println("\033[1m"+"1) "+"\033[0m"+"Contar veces que se repite una etiqueta");
                                System.out.println("\033[1m"+"2) "+"\033[0m"+"Añadir nuevo piso");
                                opcion3 = sc.nextLine();

                                if (opcion3.toLowerCase().equalsIgnoreCase("x")){
                                    salir = true;

                                }else if (!isInteger(opcion3)){
                                    System.out.println("\nLa opción no se reconoce, intentelo otra vez");

                                }else if (Integer.parseInt(opcion3) == 0){
                                    break;
                                }else if (Integer.parseInt(opcion3) == 1){
                                    while(!salir){
                                        String etiquetaAbuscar = "";
                                        System.out.println("Que etiqueta deseas buscar?");
                                        etiquetaAbuscar = sc.nextLine();

                                        if(isBlank(etiquetaAbuscar)){
                                            System.out.println("\nIntroduce algún valor");
                                            System.out.println("\t─────────\t─────────\n");
                                        }else if(existeEtiqueta("./pisos.xml", etiquetaAbuscar)){
                                            contarElementos("./pisos.xml", etiquetaAbuscar);
                                            break;
                                        }else{
                                            System.out.println("\nLa etiqueta "+etiquetaAbuscar+" no existe");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe una etiqueta que exista en el xml");
                                        }
                                    }

                                }else if (Integer.parseInt(opcion3) == 2){
                                    String direccion = "";
                                    String ciudad = "";
                                    String superficie = "";
                                    String numeroHabitaciones = "";
                                    String precioAlquiler = "";

                                    System.out.println("Valor para "+"\033[1m"+"direccion"+"\033[0m"+" (String):");
                                    direccion = sc.nextLine();

                                    System.out.println("Valor para "+"\033[1m"+"ciudad"+"\033[0m"+" (String):");
                                    ciudad = sc.nextLine();

                                    while(!salir){
                                        System.out.println("Valor para "+"\033[1m"+"superficie"+"\033[0m"+" (int):");
                                        superficie = sc.nextLine();

                                        if (!isInteger(String.valueOf(superficie))){
                                            System.out.println("\nLa respuesta no es del tipo requerido");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe un dato acorde al tipo que se solicita");
                                        }else{
                                            break;
                                        }
                                    }

                                    while(!salir){
                                        System.out.println("Valor para "+"\033[1m"+"numeroHabitaciones"+"\033[0m"+" (int):");
                                        numeroHabitaciones = sc.nextLine();

                                        if (!isInteger(String.valueOf(numeroHabitaciones))){
                                            System.out.println("\nLa respuesta no es del tipo requerido");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe un dato acorde al tipo que se solicita");
                                        }else{
                                            break;
                                        }
                                    }

                                    while(!salir){
                                        System.out.println("Valor para "+"\033[1m"+"precioAlquiler"+"\033[0m"+" (int):");
                                        precioAlquiler = sc.nextLine();

                                        if (!isInteger(String.valueOf(precioAlquiler))){
                                            System.out.println("\nLa respuesta no es del tipo requerido");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe un dato acorde al tipo que se solicita");
                                        }else{
                                            break;
                                        }
                                    }


                                    agregarPiso("./pisos.xml", direccion, ciudad, Integer.parseInt(superficie), Integer.parseInt(numeroHabitaciones), Integer.parseInt(precioAlquiler));
                                }else{
                                    System.out.println("La opción no se reconoce, intentelo otra vez");
                                }

                            }

                        }else if (Integer.parseInt(opcion2) == 3){
                            while(!salir){
                                System.out.println("\n──────────────────────────");
                                System.out.println("\nPROPIETARIOS.xml");
                                System.out.println("\033[3m"+"Selecciona la acción a realizar"+"\033[0m");
                                System.out.println("\033[1m"+"X) "+"\033[0m"+"Salir");
                                System.out.println("\033[1m"+"0) "+"\033[0m"+"Volver");
                                System.out.println("\033[1m"+"1) "+"\033[0m"+"Contar veces que se repite una etiqueta");
                                System.out.println("\033[1m"+"2) "+"\033[0m"+"Añadir nuevo propietario");
                                opcion3 = sc.nextLine();

                                if (opcion3.toLowerCase().equalsIgnoreCase("x")){
                                    salir = true;
                                }else if (!isInteger(opcion3)){
                                    System.out.println("\nLa opción no se reconoce, intentelo otra vez");

                                }else if (Integer.parseInt(opcion3) == 0){
                                    break;
                                }else if (Integer.parseInt(opcion3) == 1){
                                    while(!salir){
                                        String etiquetaAbuscar = "";
                                        System.out.println("Que etiqueta deseas buscar?");
                                        etiquetaAbuscar = sc.nextLine();

                                        if(isBlank(etiquetaAbuscar)){
                                            System.out.println("\nIntroduce algún valor");
                                            System.out.println("\t─────────\t─────────\n");
                                        }else if(existeEtiqueta("./propietarios.xml", etiquetaAbuscar)){
                                            contarElementos("./propietarios.xml", etiquetaAbuscar);
                                            break;
                                        }else{
                                            System.out.println("\nLa etiqueta "+etiquetaAbuscar+" no existe");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe una etiqueta que exista en el xml");
                                        }
                                    }

                                }else if (Integer.parseInt(opcion3) == 2){
                                    String nombre = "";
                                    String telefono = "";
                                    String correo = "";
                                    String propiedades = "";

                                    System.out.println("Valor para "+"\033[1m"+"nombre"+"\033[0m"+" (String):");
                                    nombre = sc.nextLine();

                                    while(!salir){
                                        System.out.println("Valor para "+"\033[1m"+"telefono"+"\033[0m"+" (int):");
                                        telefono = sc.nextLine();

                                        if (!isInteger(String.valueOf(telefono))){
                                            System.out.println("\nLa respuesta no es del tipo requerido");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe un dato acorde al tipo que se solicita");
                                        }else{
                                            break;
                                        }
                                    }

                                    System.out.println("Valor para "+"\033[1m"+"correo"+"\033[0m"+" (String):");
                                    correo = sc.nextLine();

                                    while(!salir){
                                        System.out.println("Valor para "+"\033[1m"+"propiedades"+"\033[0m"+" (int):");
                                        propiedades = sc.nextLine();

                                        if (!isInteger(String.valueOf(propiedades))){
                                            System.out.println("\nLa respuesta no es del tipo requerido");
                                            System.out.println("\t─────────\t─────────");
                                            System.out.println("\nPorfavor, escribe un dato acorde al tipo que se solicita");
                                        }else{
                                            break;
                                        }
                                    }

                                    agregarPropietario("./propietarios.xml", nombre, Integer.parseInt(telefono), correo, Integer.parseInt(propiedades));
                                }else{
                                    System.out.println("La opción no se reconoce, intentelo otra vez");
                                }

                            }


                        }else{
                            System.out.println("La opción no se reconoce, intentelo otra vez");
                        }


                    }
                }else{
                    System.out.println("La opción no se reconoce, intentelo otra vez");
                }
            }
        }

    public static boolean isBlank(String cadena) {
        if (cadena == null || cadena.trim().isEmpty()) {
            return true;
        }
        return false;
    }

    public static void contarElementos(String archivoXML, String etiquetaElemento) throws Exception {
        File xmlFile = new File(archivoXML);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        NodeList listaElementos = doc.getElementsByTagName(etiquetaElemento);
        System.out.println("\nNúmero total de "+etiquetaElemento+"s: "+listaElementos.getLength());
    }

    public static boolean existeEtiqueta(String archivoXML, String etiquetaElemento) throws Exception {
        File xmlFile = new File(archivoXML);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        // Verificar si la etiqueta existe en el archivo XML
        NodeList listaElementos = doc.getElementsByTagName(etiquetaElemento);
        return listaElementos.getLength() > 0;
    }

    public static void agregarInquilino(String archivoInquilinos, String nombre, int telefono, String correo, int duracionContrato) throws Exception {
        // Leer el archivo XML como una cadena
        String xmlContent = new String(Files.readAllBytes(Paths.get(archivoInquilinos)));

        // Buscar el último ID de inquilino
        int ultimoID = obtenerUltimoID(xmlContent);

        // Nuevo ID será el último ID más 1
        int nuevoID = ultimoID + 1;

        // Crear el nuevo nodo de inquilino con el formato exacto que quieres
        String nuevoInquilino = "    <Inquilino>\n" +
                "        <ID>" + nuevoID + "</ID>\n" +
                "        <Nombre>" + nombre + "</Nombre>\n" +
                "        <Telefono>" + telefono + "</Telefono>\n" +
                "        <Correo>" + correo + "</Correo>\n" +
                "        <DuracionContrato>" + duracionContrato + "</DuracionContrato>\n" +
                "    </Inquilino>\n";

        // Insertar el nuevo inquilino antes del cierre de la etiqueta </Inquilinos>
        xmlContent = xmlContent.replace("</Inquilinos>", nuevoInquilino + "</Inquilinos>");

        // Escribir el contenido actualizado en el archivo XML
        BufferedWriter writer = new BufferedWriter(new FileWriter(archivoInquilinos));
        writer.write(xmlContent);
        writer.close();

        // Mensaje de confirmación
        System.out.println("\t─────────\t─────────");
        System.out.println("\nInquilino agregado correctamente:\n");
        System.out.println("\tID: " + nuevoID);
        System.out.println("\tNombre: " + nombre);
        System.out.println("\tTeléfono: " + telefono);
        System.out.println("\tCorreo: " + correo);
        System.out.println("\tDuracion del contrato: " + duracionContrato);
    }

    public static void agregarPiso(String archivoPisos, String direccion, String ciudad, int superficie, int numeroHabitaciones, int precioAlquiler) throws Exception {
        // Leer el archivo XML como una cadena
        String xmlContent = new String(Files.readAllBytes(Paths.get(archivoPisos)));

        // Buscar el último ID de Piso
        int ultimoID = obtenerUltimoID(xmlContent);

        // Nuevo ID será el último ID más 1
        int nuevoID = ultimoID + 1;

        // Crear el nuevo nodo de piso con el formato exacto que quieres
        String nuevoPiso = "    <Piso>\n" +
                "        <ID>" + nuevoID + "</ID>\n" +
                "        <Direccion>" + direccion + "</Direccion>\n" +
                "        <Ciudad>" + ciudad + "</Ciudad>\n" +
                "        <Superficie>" + superficie + "</Superficie>\n" +
                "        <NumeroHabitaciones>" + numeroHabitaciones + "</NumeroHabitaciones>\n" +
                "        <PrecioAlquiler>" + precioAlquiler + "</PrecioAlquiler>\n" +
                "    </Piso>\n";

        // Insertar el nuevo piso antes del cierre de la etiqueta </Pisos>
        xmlContent = xmlContent.replace("</Pisos>", nuevoPiso + "</Pisos>");

        // Escribir el contenido actualizado en el archivo XML
        BufferedWriter writer = new BufferedWriter(new FileWriter(archivoPisos));
        writer.write(xmlContent);
        writer.close();

        // Mensaje de confirmación
        System.out.println("\t─────────\t─────────");
        System.out.println("\nPiso agregado correctamente:\n");
        System.out.println("\tID: " + nuevoID);
        System.out.println("\tDireccion: " + direccion);
        System.out.println("\tCiudad: " + ciudad);
        System.out.println("\tSuperficie: " + superficie);
        System.out.println("\tNumero de Habitaciones: " + numeroHabitaciones);
        System.out.println("\tPrecio de Alquiler: " + precioAlquiler);
    }

    public static void agregarPropietario(String archivoPropietarios, String nombre, int telefono, String correo, int propiedades) throws Exception {
        // Leer el archivo XML como una cadena
        String xmlContent = new String(Files.readAllBytes(Paths.get(archivoPropietarios)));

        // Buscar el último ID de Propietario
        int ultimoID = obtenerUltimoID(xmlContent);

        // Nuevo ID será el último ID más 1
        int nuevoID = ultimoID + 1;

        // Crear el nuevo nodo de propietario con el formato exacto que quieres
        String nuevoPropietario = "    <Propietario>\n" +
                "        <ID>" + nuevoID + "</ID>\n" +
                "        <Nombre>" + nombre + "</Nombre>\n" +
                "        <Telefono>" + telefono + "</Telefono>\n" +
                "        <Correo>" + correo + "</Correo>\n" +
                "        <Propiedades>" + propiedades + "</Propiedades>\n" +
                "    </Propietario>\n";

        // Insertar el nuevo propietario antes del cierre de la etiqueta </Propietarios>
        xmlContent = xmlContent.replace("</Propietarios>", nuevoPropietario + "</Propietarios>");

        // Escribir el contenido actualizado en el archivo XML
        BufferedWriter writer = new BufferedWriter(new FileWriter(archivoPropietarios));
        writer.write(xmlContent);
        writer.close();

        // Mensaje de confirmación
        System.out.println("\t─────────\t─────────");
        System.out.println("\nPropietario agregado correctamente:\n");
        System.out.println("\tID: " + nuevoID);
        System.out.println("\tNombre: " + nombre);
        System.out.println("\tTeléfono: " + telefono);
        System.out.println("\tCorreo: " + correo);
        System.out.println("\tPropiedades: " + propiedades);
    }


    // Método para obtener el último ID
    private static int obtenerUltimoID(String xmlContent) {
        // Expresión regular para encontrar todos los IDs
        Pattern pattern = Pattern.compile("<ID>(\\d+)</ID>");
        Matcher matcher = pattern.matcher(xmlContent);

        int maxID = 0;
        // Recorrer todos los matches para encontrar el mayor ID
        while (matcher.find()) {
            int id = Integer.parseInt(matcher.group(1));
            if (id > maxID) {
                maxID = id;
            }
        }
        return maxID;
    }

        public static boolean isInteger(String str) {
            try {
                Integer.parseInt(str);
                return true;
            } catch (NumberFormatException nfe) {
                return false;
            }
        }

        public static void listarArchivos(){
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduzca la ruta absoluta del archivo que desea comprobar: ");
            String rutaArchivo = sc.next();
            File archivo = new File(rutaArchivo);

            if (!archivo.exists()) {
                System.out.println(rutaArchivo + "\n Error, el archivo no existe.");
                System.exit(0);

            } else {

                if (archivo.isDirectory()) {
                    System.out.println(archivo.getName() + " es un directorio. Contenidos: ");
                    String[] listaContenidos = archivo.list();

                    for (String contenido : listaContenidos) {
                        File contenidoFile = new File(contenido);
                        StringBuilder sb = new StringBuilder("");

                        sb.append(contenidoFile.getName()+"\n");
                        System.out.print(sb.toString());

                    }
                }else if (archivo.isFile()){
                    System.out.println(archivo.getName() + " es un directorio.");
                }

            }
        }


        public static void listarArchivosDetallado(){
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduzca la ruta absoluta del archivo que desea comprobar: ");
            String rutaArchivo = sc.next();
            File archivo = new File(rutaArchivo);

            if (!archivo.exists()) {
                System.out.println(rutaArchivo + "\n Error, el archivo no existe.");
                System.exit(0);

            } else {

                if (archivo.isDirectory()) {
                    System.out.println(archivo.getName() + " es un directorio. Contenidos: ");
                    String[] listaContenidos = archivo.list();

                    for (String contenido : listaContenidos) {
                        File contenidoFile = new File(contenido);
                        StringBuilder sb = new StringBuilder("");

                        DateFormat formateador = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
                        long fecha = archivo.lastModified();

                        if(contenidoFile.isDirectory()) {
                            sb.append("(/) " )
                                    .append(contenidoFile.getName()+" ")
                                    .append("[")
                                    .append(archivo.canRead() ? "r" : "-")
                                    .append(archivo.canExecute() ? "e" : "-")
                                    .append(archivo.canWrite() ? "w" : "-")
                                    .append("," + formateador.format(fecha))
                                    .append("]\n");

                        } else if (contenidoFile.isFile()) {
                            sb.append("(_) ")
                                    .append(contenidoFile.getName()+" ")
                                    .append("[")
                                    .append((contenidoFile.length()/0.125))
                                    .append(" bytes,")
                                    .append(archivo.canRead() ? "r" : "-")
                                    .append(archivo.canExecute() ? "x" : "-")
                                    .append(archivo.canWrite() ? "w" : "-")
                                    .append(", " + formateador.format(fecha))
                                    .append("]\n");
                        }

                        System.out.print(sb.toString());

                    }
                }
            }
        }


        public static void crearCarpeta(){
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduzca la ruta donde quiere crear la carpeta: ");
            Path dirPath = Path.of(sc.nextLine());

            boolean result = false;

            if (Files.notExists(dirPath)) {
                File directory = new File(dirPath.toUri());
                System.out.println("Carpeta creada correctamente");
                result = directory.mkdir();
            }
        }


        public static void copiarArchivo() {
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduce la ruta del archivo que quieres copiar");
            String fromFile = sc.nextLine();
            System.out.println("Introduce la ruta del archivo donde lo quieres copiar");
            String toFile = sc.nextLine();

            File origin = new File(fromFile);
            File destination = new File(toFile);
            if (origin.exists()) {
                try {
                    FileUtils.copyFileToDirectory(origin, destination);
                    System.out.println("Archivo copiado correctamente");
                } catch (IOException e) {
                    System.out.println("Error al copiar el archivo \n" + e.getMessage());
                }
            }

        }



    public static void moverArchivo() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce la ruta del archivo que quieres mover");
        String fromFile = sc.nextLine();
        System.out.println("Introduce la ruta a donde lo quieres mover");
        String toFile = sc.nextLine();

        File source = new File(fromFile);
        File dest = new File(toFile);
        boolean bool = source.renameTo(dest);
        if(bool) {
            System.out.println("Archivo movido correctamente");
        }
        else {
            System.out.println("Error al mover el archivo");
        }

    }

}