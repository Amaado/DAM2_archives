import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);

            String opcion = "";

            System.out.println("=====================");
            System.out.println("  EDITOR DE FICHEROS");
            System.out.println("=====================");

            while(true){
                System.out.println("\033[3m"+"\nSelct an option by writting a number"+"\033[0m");

                System.out.println("\033[1m"+"0) "+"\033[0m"+"Salir");
                System.out.println("\033[1m"+"1) "+"\033[0m"+"Listar archivos de forma simplificada");
                System.out.println("\033[1m"+"2) "+"\033[0m"+"Listar archivos de forma detallada");
                System.out.println("\033[1m"+"3) "+"\033[0m"+"Crear carpeta");
                System.out.println("\033[1m"+"4) "+"\033[0m"+"Copiar archivo");
                System.out.println("\033[1m"+"5) "+"\033[0m"+"Mover archivo");
                opcion = sc.nextLine();



                if (!isInteger(opcion)){
                    System.out.println("La opción no se reconoce, intentelo otra vez");
                }else if (Integer.parseInt(opcion) == 0){
                    break;
                }else if (Integer.parseInt(opcion) == 1){
                    listarArchivos();
                }else if (Integer.parseInt(opcion) == 2){
                    listarArchivosDetallado();
                }else if (Integer.parseInt(opcion) == 3){
                    crearCarpeta();
                }else if (Integer.parseInt(opcion) == 4){
                    copiarArchivo();
                }else if (Integer.parseInt(opcion) == 5){
                    moverArchivo();
                }else{
                    System.out.println("La opción no se reconoce, intentelo otra vez");
                }
            }

            System.out.println("\nAdiós!");
        }

        public static boolean isInteger(String str) {
            try {
                Integer.parseInt(str);
                return true;
            } catch (NumberFormatException nfe) {
                return false;
            }
        }

        public static void listarArchivos(){
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduzca la ruta absoluta del archivo que desea comprobar: ");
            String rutaArchivo = sc.next();
            File archivo = new File(rutaArchivo);

            if (!archivo.exists()) {
                System.out.println(rutaArchivo + "\n Error, el archivo no existe.");
                System.exit(0);

            } else {

                if (archivo.isDirectory()) {
                    System.out.println(archivo.getName() + " es un directorio. Contenidos: ");
                    String[] listaContenidos = archivo.list();

                    for (String contenido : listaContenidos) {
                        File contenidoFile = new File(contenido);
                        StringBuilder sb = new StringBuilder("");

                        sb.append(contenidoFile.getName()+"\n");
                        System.out.print(sb.toString());

                    }
                }else if (archivo.isFile()){
                    System.out.println(archivo.getName() + " es un directorio.");
                }

            }
        }


        public static void listarArchivosDetallado(){
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduzca la ruta absoluta del archivo que desea comprobar: ");
            String rutaArchivo = sc.next();
            File archivo = new File(rutaArchivo);

            if (!archivo.exists()) {
                System.out.println(rutaArchivo + "\n Error, el archivo no existe.");
                System.exit(0);

            } else {

                if (archivo.isDirectory()) {
                    System.out.println(archivo.getName() + " es un directorio. Contenidos: ");
                    String[] listaContenidos = archivo.list();

                    for (String contenido : listaContenidos) {
                        File contenidoFile = new File(contenido);
                        StringBuilder sb = new StringBuilder("");

                        DateFormat formateador = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
                        long fecha = archivo.lastModified();

                        if(contenidoFile.isDirectory()) {
                            sb.append("(/) " )
                                    .append(contenidoFile.getName()+" ")
                                    .append("[")
                                    .append(archivo.canRead() ? "r" : "-")
                                    .append(archivo.canExecute() ? "e" : "-")
                                    .append(archivo.canWrite() ? "w" : "-")
                                    .append("," + formateador.format(fecha))
                                    .append("]\n");

                        } else if (contenidoFile.isFile()) {
                            sb.append("(_) ")
                                    .append(contenidoFile.getName()+" ")
                                    .append("[")
                                    .append((contenidoFile.length()/0.125))
                                    .append(" bytes,")
                                    .append(archivo.canRead() ? "r" : "-")
                                    .append(archivo.canExecute() ? "x" : "-")
                                    .append(archivo.canWrite() ? "w" : "-")
                                    .append(", " + formateador.format(fecha))
                                    .append("]\n");
                        }

                        System.out.print(sb.toString());

                    }
                }
            }
        }


        public static void crearCarpeta(){
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduzca la ruta donde quiere crear la carpeta: ");
            Path dirPath = Path.of(sc.nextLine());

            boolean result = false;

            if (Files.notExists(dirPath)) {
                File directory = new File(dirPath.toUri());
                System.out.println("Carpeta creada correctamente");
                result = directory.mkdir();
            }
        }


        public static void copiarArchivo() {
            Scanner sc = new Scanner(System.in);

            System.out.println("Introduce la ruta del archivo que quieres copiar");
            String fromFile = sc.nextLine();
            System.out.println("Introduce la ruta del archivo donde lo quieres copiar");
            String toFile = sc.nextLine();

            File origin = new File(fromFile);
            File destination = new File(toFile);
            if (origin.exists()) {
                try {
                    FileUtils.copyFileToDirectory(origin, destination);
                    System.out.println("Archivo copiado correctamente");
                } catch (IOException e) {
                    System.out.println("Error al copiar el archivo \n" + e.getMessage());
                }
            }

        }



    public static void moverArchivo() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce la ruta del archivo que quieres mover");
        String fromFile = sc.nextLine();
        System.out.println("Introduce la ruta a donde lo quieres mover");
        String toFile = sc.nextLine();

        File source = new File(fromFile);
        File dest = new File(toFile);
        boolean bool = source.renameTo(dest);
        if(bool) {
            System.out.println("Archivo movido correctamente");
        }
        else {
            System.out.println("Error al mover el archivo");
        }

    }

}