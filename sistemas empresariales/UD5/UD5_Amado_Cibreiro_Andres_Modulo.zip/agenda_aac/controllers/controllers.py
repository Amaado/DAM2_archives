# -*- coding: utf-8 -*-
# from odoo import http


# class AgendaAac(http.Controller):
#     @http.route('/agenda_aac/agenda_aac', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/agenda_aac/agenda_aac/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('agenda_aac.listing', {
#             'root': '/agenda_aac/agenda_aac',
#             'objects': http.request.env['agenda_aac.agenda_aac'].search([]),
#         })

#     @http.route('/agenda_aac/agenda_aac/objects/<model("agenda_aac.agenda_aac"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('agenda_aac.object', {
#             'object': obj
#         })

