# -*- coding: utf-8 -*-

from odoo import models, fields, api				#Importa modelos, campos y API de Odoo


class agenda_aac(models.Model):                                 #Creación de nueva clase que actuará como modelo
    _name = 'agenda_aac.agenda_aac'                             #Declaración de atributos de la clase (nombre)
    _description = 'agenda_aac.agenda_aac'                      #Declaracrón de atributos de la clase (descripcion)

    name = fields.Char(string='Nombre')                         #Declaración de campo name (Aparecerá escrito un string 'Nombre')
    telephone = fields.Char(String='Teléfono')                  #Declaración del campo telephone (Aparecerá escrito un string 'Teléfono')
#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100

