package controller;

import controller.converter.ConverterController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.MainJFrame;
import view.converter.ConverterDialog;


public class FrontController {
    
    private MainJFrame view;
    
    public FrontController(MainJFrame view) {
        this.view = view;
        this.view.addQuitMenuItemActionListener(this.getQuitMenuItemActionListener());
        this.view.addConvertDistancesMenuItemActionListener(this.getConvertDistancesMenuItemActionListener());
    }
    
    private ActionListener getQuitMenuItemActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
                System.exit(0);
            }
        };
        return al;
    }
    
    private ActionListener getConvertDistancesMenuItemActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ConverterDialog cd = new ConverterDialog(view, true);
                ConverterController cc = new ConverterController(cd);
                cd.setVisible(true);
            }
        };
        return al;
    }
    
}
