
package controller.converter;

import view.converter.ConverterDialog;

public class ConverterController {
    
    private ConverterDialog view;
    
    public ConverterController(ConverterDialog view) {
        this.view = view;
        
    }
    
}
