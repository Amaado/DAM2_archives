package model;

public final class ConvertLength {
    // 1 mile= 1,60934 km
    // 1 km  = 0,621371 miles
    
    
    private ConvertLength(){/*Constructor privado y sin cuerpo para que no se pueda crear una instancia de esta clase*/}               

    public static double milesToKm(double miles) {
        return miles*1.60934;
    }
    
    public static double kmsoMiles(double kms){
        return kms*0.621371;               
    }
    
}
