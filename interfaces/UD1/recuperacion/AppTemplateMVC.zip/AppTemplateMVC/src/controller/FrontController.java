/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import controller.userInformation.GestionarDonacionesBibliograficasController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.MainJFrame;
import view.userInformation.GestionarDonacionesBibliograficasDialog;

/**
 *
 * @author dides
 */
public class FrontController {

    private MainJFrame view;

    public FrontController(MainJFrame view) {
        this.view = view;
        this.view.addQuitMenuItemListener(this.getQuitMenuItemActionListener());
        this.view.addGestionarDonacionesBibliograficasMenuItemListener(this.getGestionarDonacionesBibliograficasMenuItemActionListener());
    }

    private ActionListener getGestionarDonacionesBibliograficasMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionarDonacionesBibliograficasDialog gdbd = new GestionarDonacionesBibliograficasDialog(view, true);
                GestionarDonacionesBibliograficasController gdbc = new GestionarDonacionesBibliograficasController(gdbd);
                gdbd.setVisible(true);
            }
        };
        return al;
    }

    private ActionListener getQuitMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
                System.exit(0);
            }
        };
        return al;
    }

}
