package controller;

import controller.book.BookController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.MainJFrame;
import view.book.BookDialog;


public class FrontController {
    private MainJFrame view;

    public FrontController(MainJFrame view) {
        this.view = view;
        this.view.addBookMenuItemActionListener(this.getBookMenuItemListener());
        this.view.addQuitMenuItemActionListener(this.getQuitMenuActionListener());
    }
    
    
    private ActionListener getBookMenuItemListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BookDialog bd = new BookDialog(view, true);
                BookController bc = new BookController(bd);
                bd.setVisible(true);
            }
        };
        return al;
    }
    
    private ActionListener getQuitMenuActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
                System.exit(0);
            }
        };

        return al;
    }
    
}
