package controller.book;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import view.book.BookDialog;
import model.isNumeric.IsNumeric;

public class BookController {
    private final BookDialog view;

    public BookController(BookDialog view) {
        this.view = view;
        this.view.addSubmitButtonActionListener(this.getSubmitButtonActionListener());
        this.view.setErrorLabelInvisible();
        this.view.addCancelButtonActionListener(this.getCancelButtonActionListener());
        this.view.addClearButtonActionListener(this.getClearButtonActionListener());
    }
    
    private ActionListener getSubmitButtonActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = view.getName();
                String email = view.getEmail();
                String phone = view.getPhone();
                String date = view.getDate();
                int numberAttendees = view.getNumberAttendees();
                String typeEvent = view.getTypeEvent();
                String kitchen = view.getKitchen();
                int kitchenValue = view.getKitchenSelectedIndex();
                boolean rooms = view.isRoomsSelected();
                
                view.setNameColorDefault();
                view.setEmailColorDefault();
                view.setPhoneColorDefault();
                view.setDateColorDefault();
                view.setNumberAttendeesColorDefault();
                view.setTypeEventColorDefault();
                view.setKitchenColorDefault();

                              
                if(name.isBlank() || email.isBlank() || phone.isBlank() || !IsNumeric.isNumeric(phone)
                        || date.isBlank() || numberAttendees == 0 || kitchenValue == 0 || !view.isEventTypeSelected()){
                    String err = "*One or more fields are blank or not a valid value";
                    view.setErrorLabelVisible();
                    view.setErrorLabelText(err);
                    
                    if(name.isBlank()){
                        view.setNameColorRed();
                    }

                    if(email.isBlank()){
                        view.setEmailColorRed();
                    }

                    if(phone.isBlank() || !IsNumeric.isNumeric(phone)){
                        view.setPhoneColorRed();
                    }

                    if(date.isBlank()){
                        view.setDateColorRed();
                    }

                    if(numberAttendees == 0 ){
                        view.setNumberAttendeesColorRed();
                    }

                    if(!view.isEventTypeSelected()){
                        view.setTypeEventColorRed();
                    }

                    if(kitchenValue == 0){
                        view.setKitchenColorRed();
                    }
                
                }else{
                    view.setErrorLabelInvisible();
                    JOptionPane.showMessageDialog(view, "SALON PALACE\n" + "BOOK RESULT\n_____________\n" +
                        "Name: " + name + 
                        "\nEmail: " + email +
                        "\nPhone: " + phone +
                        "\nDate: " + date +
                        "\nNumer of attendees: " + numberAttendees +
                        "\nType of event: " + typeEvent +
                        "\nKitchen: " + kitchen +
                        "\nNeed rooms for attendees? "+(rooms?"Yes":"No"));
                    }
                }
                
                
        };
        return al;
    }
    
    
    private ActionListener getCancelButtonActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        };
        return al;
    }
    
    private ActionListener getClearButtonActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setClear();
                
            }
        };
        return al;
    }
        
        
}
