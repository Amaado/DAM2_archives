package diControls;

import java.awt.Color;
import java.awt.Font;
import java.beans.*;
import java.io.Serializable;
import javax.swing.JTextField;

/**
 *
 * @author aca
 */
public class DiTextField extends JTextField implements Serializable {
    
    private Color color;
    private int ancho;
    private Font fuente;
    
    /**
     *
     */
    public DiTextField() {
        this.setColor(new Color(255, 0, 0));
        this.setAncho(15);
        this.setFuente(new Font( "MathJax_Typewriter",Font.ITALIC,16 ));
    }
       
    /**
     *
     * @return
     */
    public Color getColor() {
        return color;
    }

    /**
     *
     * @param color
     */
    public void setColor(Color color) {
        this.color = color;
        this.setBackground(color);
    }
    
    /**
     *
     * @return
     */
    public int getAncho() {
        return ancho;
    }

    /**
     *
     * @param ancho
     */
    public void setAncho(int ancho) {
        this.ancho = ancho;
        this.setColumns(ancho);
    }
    
    /**
     *
     * @return
     */
    public Font getFuente() {
        return fuente;
    }

    /**
     *
     * @param fuente
     */
    public void setFuente(Font fuente) {
        this.fuente = fuente;
        this.setFont(fuente);
    }



    
}
