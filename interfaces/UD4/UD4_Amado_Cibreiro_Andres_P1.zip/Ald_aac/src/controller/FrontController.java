package controller;

import clock.AlarmEvent;
import clock.IAlarmListener;
import controller.clock.ClockController;
import controller.computersManagement.ComputersManagementController;
import controller.establishementInformation.EstablishementInformationController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.Ald.Ald;
import view.establishmentInformation.EstablishmentInformationDialog;
import view.MainJFrame;
import view.clock.ClockConfigurationDialog;
import view.computersManagement.ComputersManagementDialog;

public class FrontController implements IAlarmListener {

    private final MainJFrame view;
    private Ald ald;

    public FrontController(MainJFrame view, Ald ald) {
        this.view = view;
        this.ald = ald;
        this.view.addEstablishmentInformationMenuItemActionListener(this.getEstablishmentInformationMenuItemActionListener());
        this.view.addComputersManagementMenuItemActionListener(this.getComputersManagementMenuItemActionListener());
        this.view.addQuitMenuItemActionListener(this.getQuitMenuItemActionListener());
        this.view.addNotificationMenuItemItemListener(this.getNotificationMenuItemItemListener());
        configureNotificationReceptor();
    }

    private ActionListener getEstablishmentInformationMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EstablishmentInformationDialog eid = new EstablishmentInformationDialog(view, true);
                EstablishementInformationController eic = new EstablishementInformationController(eid, ald);
                eid.setVisible(true);
            }
        };
        return al;
    }
    
    private ActionListener getComputersManagementMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ComputersManagementDialog cmd = new ComputersManagementDialog(view, true);
                ComputersManagementController cmc = new ComputersManagementController(cmd, ald);
                cmd.setVisible(true);
            }
        };
        return al;
    }
    
    private ActionListener getQuitMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
                System.exit(0);
            }
        };
        return al;
    }
    
    
    
        private ActionListener getNotificationMenuItemItemListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ClockConfigurationDialog ccd = new ClockConfigurationDialog(view, true);
                ClockController cc = new ClockController(view, ccd);
                ccd.setVisible(true);
            }
        };
        return al;
    }

    private void configureNotificationReceptor() {
        this.view.addAlarmListener(this);
    }

    @Override
    public void captureAlarm(AlarmEvent ev) {
        view.setEnableAlarm(false);
        JOptionPane.showMessageDialog(view, view.getAlarmMessage());
    }
    
}
