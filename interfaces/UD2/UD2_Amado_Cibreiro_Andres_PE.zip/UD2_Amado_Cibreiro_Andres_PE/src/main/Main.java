/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import controller.FrontController;
import model.Hotel;
import view.MainFrame;

/**
 *
 * @author dides
 */
public class Main {
    public static void main(String[] args) {
        MainFrame mainview=new MainFrame();
        Hotel ht=new Hotel();
        ht.populate();
        FrontController fc=new FrontController(mainview,ht);
        mainview.setVisible(true);
        
    }
}
