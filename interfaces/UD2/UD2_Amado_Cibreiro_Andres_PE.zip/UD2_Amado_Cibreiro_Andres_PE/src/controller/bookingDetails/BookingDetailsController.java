/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.bookingDetails;

import model.Booking;
import model.Hotel;
import view.bookingDetails.BookingDetailsDialog;

/**
 *
 * @author aca
 */
public class BookingDetailsController {
    private Hotel model;
    private BookingDetailsDialog view;
    private String name;

    public BookingDetailsController(Hotel model, BookingDetailsDialog view, String name) {
        this.model = model;
        this.view = view;
        this.name = name;
        this.initDialog();
    }
    
    private void initDialog() {
        Booking booking = model.getBooking(name);
        view.setFieldsDisabled();
        view.setBookingHolderTextField(booking.getHolder());
        view.setRoomTypeComboBox(booking.getRoomType().toString());
        view.setSmokerCheckBox(booking.isSmoker());
        view.setWifiCheckBox(booking.isWifi());
    }
}
