/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import controller.booking.BookingController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Hotel;
import view.MainFrame;
import view.booking.BookingDialog;

/**
 *
 * @author dides
 */
public class FrontController {

    private MainFrame view;
    private Hotel model;

    public FrontController(MainFrame view, Hotel model) {
        this.view = view;
        this.model = model;
        this.view.setQuitMenuItemListener(this.getQuitMenuItemActionListener());
        this.view.setShowBookingMenuItemListener(this.getShowBookingMenuItemActionListener());
    }

    private ActionListener getQuitMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        };
        return al;
    }

    private ActionListener getShowBookingMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BookingDialog bd = new BookingDialog(view, true);
                BookingController bdc = new BookingController(view,bd, model);
                bd.setVisible(true);
            }
        };
        return al;
    }
}
