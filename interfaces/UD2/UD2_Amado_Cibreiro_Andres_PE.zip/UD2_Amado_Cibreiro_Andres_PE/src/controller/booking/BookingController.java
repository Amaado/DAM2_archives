/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.booking;

import controller.bookingDetails.BookingDetailsController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Hotel;
import view.MainFrame;
import view.booking.BookingDialog;
import view.bookingDetails.BookingDetailsDialog;

/**
 *
 * @author fermigo
 */
public class BookingController {

    public static String DEFAULTSTR = "Select...";
    private BookingDialog view;
    private Hotel model;
    private MainFrame parentFrame;

    public BookingController(MainFrame parentFrame, BookingDialog view, Hotel model) {
        this.parentFrame = parentFrame;
        this.view = view;
        this.model = model;
        this.view.addBookingHolderComboBoxListener(this.getBookingHolderComboBoxListener());
        this.view.addShowBookingDetailsButtonListener(this.getShowBookingDetailsButtonListener());
        this.initDialog();
    }

    private void initDialog() {
        this.view.addBookingHolder(DEFAULTSTR);
        for (String holder : model.getBooking().keySet()) {
            this.view.addBookingHolder(holder);
        }
        this.view.setBookingHolderEnabled(true);
        this.view.setShowBookingDetailsEnabled(false);
    }

    private ActionListener getBookingHolderComboBoxListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (view.getBookingHolder().equals(DEFAULTSTR)) {
                    view.setShowBookingDetailsEnabled(false);
                } else {
                    view.setShowBookingDetailsEnabled(true);
                }
            }
        };
        return al;
    }
    
    private ActionListener getShowBookingDetailsButtonListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = view.getBookingHolder();
                BookingDetailsDialog bdd = new BookingDetailsDialog(view, true);
                BookingDetailsController bdc = new BookingDetailsController(model, bdd, name);
                bdd.setVisible(true);
            }
        };
        return al;
    }


}
